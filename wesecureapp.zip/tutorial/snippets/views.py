from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
import subprocess
import os
import json
class SnippetList(APIView):
    def get(self, request, format=None):
        return JsonResponse({"hello":"world"})

    def post(self, request, format=None):
        data=request.data
        if data['target']:
            #cmd = 'trivy image -f json -o /home/shashi/wesecureapp/tutorial/results.json '+data['target']
            cmd_arg = ['trivy','image','-f','json','-o','results.json','golang:1.12-alpine']
            process = subprocess.Popen(cmd_arg, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = process.communicate()
            #print(stdout,stderr)
            process1 = subprocess.Popen(['cat','results.json'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            stdou, stder = process1.communicate()
            #print(stdou,stder)
            op = json.dumps(stdou)
            return JsonResponse(op)
